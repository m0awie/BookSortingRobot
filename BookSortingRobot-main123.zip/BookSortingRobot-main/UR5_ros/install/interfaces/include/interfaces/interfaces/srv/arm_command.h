// generated from rosidl_generator_c/resource/idl.h.em
// with input from interfaces:srv/ArmCommand.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__ARM_COMMAND_H_
#define INTERFACES__SRV__ARM_COMMAND_H_

#include "interfaces/srv/detail/arm_command__struct.h"
#include "interfaces/srv/detail/arm_command__functions.h"
#include "interfaces/srv/detail/arm_command__type_support.h"

#endif  // INTERFACES__SRV__ARM_COMMAND_H_
