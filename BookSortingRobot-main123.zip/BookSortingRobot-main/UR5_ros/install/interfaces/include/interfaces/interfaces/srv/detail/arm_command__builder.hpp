// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from interfaces:srv/ArmCommand.idl
// generated code does not contain a copyright notice

#ifndef INTERFACES__SRV__DETAIL__ARM_COMMAND__BUILDER_HPP_
#define INTERFACES__SRV__DETAIL__ARM_COMMAND__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "interfaces/srv/detail/arm_command__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace interfaces
{

namespace srv
{

namespace builder
{

class Init_ArmCommand_Request_qw
{
public:
  explicit Init_ArmCommand_Request_qw(::interfaces::srv::ArmCommand_Request & msg)
  : msg_(msg)
  {}
  ::interfaces::srv::ArmCommand_Request qw(::interfaces::srv::ArmCommand_Request::_qw_type arg)
  {
    msg_.qw = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

class Init_ArmCommand_Request_qz
{
public:
  explicit Init_ArmCommand_Request_qz(::interfaces::srv::ArmCommand_Request & msg)
  : msg_(msg)
  {}
  Init_ArmCommand_Request_qw qz(::interfaces::srv::ArmCommand_Request::_qz_type arg)
  {
    msg_.qz = std::move(arg);
    return Init_ArmCommand_Request_qw(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

class Init_ArmCommand_Request_qy
{
public:
  explicit Init_ArmCommand_Request_qy(::interfaces::srv::ArmCommand_Request & msg)
  : msg_(msg)
  {}
  Init_ArmCommand_Request_qz qy(::interfaces::srv::ArmCommand_Request::_qy_type arg)
  {
    msg_.qy = std::move(arg);
    return Init_ArmCommand_Request_qz(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

class Init_ArmCommand_Request_qx
{
public:
  explicit Init_ArmCommand_Request_qx(::interfaces::srv::ArmCommand_Request & msg)
  : msg_(msg)
  {}
  Init_ArmCommand_Request_qy qx(::interfaces::srv::ArmCommand_Request::_qx_type arg)
  {
    msg_.qx = std::move(arg);
    return Init_ArmCommand_Request_qy(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

class Init_ArmCommand_Request_z
{
public:
  explicit Init_ArmCommand_Request_z(::interfaces::srv::ArmCommand_Request & msg)
  : msg_(msg)
  {}
  Init_ArmCommand_Request_qx z(::interfaces::srv::ArmCommand_Request::_z_type arg)
  {
    msg_.z = std::move(arg);
    return Init_ArmCommand_Request_qx(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

class Init_ArmCommand_Request_y
{
public:
  explicit Init_ArmCommand_Request_y(::interfaces::srv::ArmCommand_Request & msg)
  : msg_(msg)
  {}
  Init_ArmCommand_Request_z y(::interfaces::srv::ArmCommand_Request::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_ArmCommand_Request_z(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

class Init_ArmCommand_Request_x
{
public:
  Init_ArmCommand_Request_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ArmCommand_Request_y x(::interfaces::srv::ArmCommand_Request::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_ArmCommand_Request_y(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::srv::ArmCommand_Request>()
{
  return interfaces::srv::builder::Init_ArmCommand_Request_x();
}

}  // namespace interfaces


namespace interfaces
{

namespace srv
{

namespace builder
{

class Init_ArmCommand_Response_success
{
public:
  Init_ArmCommand_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::interfaces::srv::ArmCommand_Response success(::interfaces::srv::ArmCommand_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::interfaces::srv::ArmCommand_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::interfaces::srv::ArmCommand_Response>()
{
  return interfaces::srv::builder::Init_ArmCommand_Response_success();
}

}  // namespace interfaces

#endif  // INTERFACES__SRV__DETAIL__ARM_COMMAND__BUILDER_HPP_
